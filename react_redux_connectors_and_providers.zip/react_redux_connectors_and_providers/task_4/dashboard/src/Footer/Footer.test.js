import React from 'react';
import { shallow } from 'enzyme';
import { fromJS } from 'immutable';
import { Footer, mapStateToProps } from './Footer';

describe('<Footer />', () => {
  it('renders without crashing', () => {
    expect(shallow(<Footer />).exists()).toBe(true);
  });

  it('renders the text Copyright', () => {
    expect(shallow(<Footer />).text()).toContain('Copyright');
  });

  it('does not display the contact link when there is no user', () => {
    expect(shallow(<Footer />).find('a')).toHaveLength(0);
  });

  it('displays the contact link when there is a user', () => {
    const wrapper = shallow(<Footer user={{ email: 'a@b.com', password: 'pass' }} />);
    expect(wrapper.find('a').text()).toBe('Contact us');
  });
});

describe('Footer mapStateToProps', () => {
  it('maps the user from the state', () => {
    const user = { email: 'a@b.com', password: 'pass' };
    const state = { ui: fromJS({ isUserLoggedIn: true }).set('user', user) };
    expect(mapStateToProps(state)).toEqual({ user });
  });
});
