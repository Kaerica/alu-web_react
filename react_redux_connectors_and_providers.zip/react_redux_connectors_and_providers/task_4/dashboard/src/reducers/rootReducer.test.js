import { Map } from 'immutable';
import rootReducer from './rootReducer';

describe('rootReducer', () => {
  it('has the right initial state structure', () => {
    const state = rootReducer(undefined, { type: '@@INIT' });

    expect(Object.keys(state).sort()).toEqual(['courses', 'notifications', 'ui']);
    expect(state.courses).toBeInstanceOf(Map);
    expect(state.notifications).toBeInstanceOf(Map);
    expect(state.ui).toBeInstanceOf(Map);
  });
});
