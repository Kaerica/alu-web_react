import React from 'react';
import { shallow } from 'enzyme';
import { fromJS } from 'immutable';
import { Header, mapStateToProps } from './Header';

describe('<Header />', () => {
  it('renders without crashing', () => {
    expect(shallow(<Header />).exists()).toBe(true);
  });

  it('renders an img and a h1', () => {
    const wrapper = shallow(<Header />);
    expect(wrapper.find('img')).toHaveLength(1);
    expect(wrapper.find('h1').text()).toBe('School dashboard');
  });

  it('does not render the logout section without a user', () => {
    expect(shallow(<Header />).find('#logoutSection')).toHaveLength(0);
  });

  it('renders the logout section with a user', () => {
    const wrapper = shallow(<Header user={{ email: 'a@b.com', password: 'pass' }} />);
    expect(wrapper.find('#logoutSection')).toHaveLength(1);
    expect(wrapper.find('#logoutSection strong').text()).toBe('a@b.com');
  });
});

describe('Header mapStateToProps', () => {
  it('maps the user from the state', () => {
    const user = { email: 'a@b.com', password: 'pass' };
    const state = { ui: fromJS({ isUserLoggedIn: true }).set('user', user) };
    expect(mapStateToProps(state)).toEqual({ user });
  });
});
