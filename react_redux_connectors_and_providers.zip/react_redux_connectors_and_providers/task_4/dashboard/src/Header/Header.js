import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { StyleSheet, css } from 'aphrodite';
import logo from '../assets/holberton-logo.jpg';
import { logout } from '../actions/uiActionCreators';

const styles = StyleSheet.create({
  header: {
    display: 'flex',
    alignItems: 'center',
    color: '#e0354b',
    borderBottom: '3px solid #e0354b',
  },
  logo: {
    width: '200px',
    height: '200px',
  },
  logoutSection: {
    padding: '0 24px',
  },
});

export function Header({ user, logout }) {
  return (
    <React.Fragment>
      <div className={css(styles.header)}>
        <img src={logo} className={css(styles.logo)} alt="Holberton logo" />
        <h1>School dashboard</h1>
      </div>
      {user && (
        <section id="logoutSection" className={css(styles.logoutSection)}>
          Welcome <strong>{user.email}</strong>{' '}
          <em>
            <a href="#" onClick={logout}>(logout)</a>
          </em>
        </section>
      )}
    </React.Fragment>
  );
}

Header.propTypes = {
  user: PropTypes.shape({
    email: PropTypes.string,
    password: PropTypes.string,
  }),
  logout: PropTypes.func,
};

Header.defaultProps = {
  user: null,
  logout: () => {},
};

export function mapStateToProps(state) {
  return {
    user: state.ui.get('user'),
  };
}

const mapDispatchToProps = {
  logout,
};

export default connect(mapStateToProps, mapDispatchToProps)(Header);
