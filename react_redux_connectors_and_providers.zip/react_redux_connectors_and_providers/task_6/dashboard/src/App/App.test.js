import React from 'react';
import { shallow } from 'enzyme';
import { fromJS } from 'immutable';
import { App, mapStateToProps } from './App';
import Notifications from '../Notifications/Notifications';
import Header from '../Header/Header';
import Login from '../Login/Login';
import Footer from '../Footer/Footer';
import CourseList from '../CourseList/CourseList';

describe('<App />', () => {
  it('renders without crashing', () => {
    expect(shallow(<App />).exists()).toBe(true);
  });

  it('contains Notifications, Header, Login and Footer', () => {
    const wrapper = shallow(<App />);
    expect(wrapper.find(Notifications)).toHaveLength(1);
    expect(wrapper.find(Header)).toHaveLength(1);
    expect(wrapper.find(Login)).toHaveLength(1);
    expect(wrapper.find(Footer)).toHaveLength(1);
    expect(wrapper.find(CourseList)).toHaveLength(0);
  });

  it('renders CourseList instead of Login when isLoggedIn is true', () => {
    const wrapper = shallow(<App isLoggedIn={true} />);
    expect(wrapper.find(Login)).toHaveLength(0);
    expect(wrapper.find(CourseList)).toHaveLength(1);
  });

  it('passes displayDrawer and the drawer actions to Notifications', () => {
    const displayNotificationDrawer = jest.fn();
    const hideNotificationDrawer = jest.fn();
    const wrapper = shallow(
      <App
        displayDrawer={true}
        displayNotificationDrawer={displayNotificationDrawer}
        hideNotificationDrawer={hideNotificationDrawer}
      />
    );
    const notifications = wrapper.find(Notifications);
    expect(notifications.prop('displayDrawer')).toBe(true);
    expect(notifications.prop('handleDisplayDrawer')).toBe(displayNotificationDrawer);
    expect(notifications.prop('handleHideDrawer')).toBe(hideNotificationDrawer);
  });
});

describe('mapStateToProps', () => {
  it('returns the right object when passing the state', () => {
    const state = {
      ui: fromJS({
        isUserLoggedIn: true,
        isNotificationDrawerVisible: true,
      }),
    };
    expect(mapStateToProps(state)).toEqual({ isLoggedIn: true, displayDrawer: true });
  });
});
