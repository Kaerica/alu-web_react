import notificationReducer from './notificationReducer';
import {
  markAsAread,
  setNotificationFilter,
  setLoadingState,
  setNotifications,
} from '../actions/notificationActionCreators';
import { FETCH_NOTIFICATIONS_SUCCESS, NotificationTypeFilters } from '../actions/notificationActionTypes';

const data = [
  {
    id: '1',
    author: { id: 'u1', name: { first: 'Poole', last: 'Sanders' } },
    context: { guid: 'g1', isRead: false, type: 'urgent', value: 'First' },
  },
  {
    id: '2',
    author: { id: 'u1', name: { first: 'Poole', last: 'Sanders' } },
    context: { guid: 'g2', isRead: true, type: 'default', value: 'Second' },
  },
];

describe('notificationReducer', () => {
  it('returns the default state', () => {
    const state = notificationReducer(undefined, {});
    expect(state.get('filter')).toBe('DEFAULT');
    expect(state.get('loading')).toBe(false);
    expect(state.get('messages').size).toBe(0);
    expect(state.get('notifications').size).toBe(0);
    expect(state.get('users').size).toBe(0);
  });

  it('normalizes the data on FETCH_NOTIFICATIONS_SUCCESS', () => {
    const state = notificationReducer(undefined, { type: FETCH_NOTIFICATIONS_SUCCESS, data });
    expect(state.getIn(['messages', 'g1', 'value'])).toBe('First');
    expect(state.getIn(['notifications', '2', 'context'])).toBe('g2');
    expect(state.getIn(['users', 'u1', 'name', 'first'])).toBe('Poole');
  });

  it('marks a notification as read on MARK_AS_READ', () => {
    const fetched = notificationReducer(undefined, { type: FETCH_NOTIFICATIONS_SUCCESS, data });
    const state = notificationReducer(fetched, markAsAread('g1'));
    expect(state.getIn(['messages', 'g1', 'isRead'])).toBe(true);
  });

  it('changes the filter on SET_TYPE_FILTER', () => {
    const state = notificationReducer(undefined, setNotificationFilter(NotificationTypeFilters.URGENT));
    expect(state.get('filter')).toBe('URGENT');
  });

  it('updates the loading state on SET_LOADING_STATE', () => {
    const loading = notificationReducer(undefined, setLoadingState(true));
    expect(loading.get('loading')).toBe(true);
    expect(notificationReducer(loading, setLoadingState(false)).get('loading')).toBe(false);
  });

  it('deep merges new notifications with the existing ones', () => {
    const first = notificationReducer(undefined, setNotifications([data[0]]));
    const both = notificationReducer(first, setNotifications([data[1]]));
    expect(both.get('messages').size).toBe(2);
    expect(both.getIn(['messages', 'g1', 'value'])).toBe('First');
    expect(both.getIn(['messages', 'g2', 'value'])).toBe('Second');
  });
});
