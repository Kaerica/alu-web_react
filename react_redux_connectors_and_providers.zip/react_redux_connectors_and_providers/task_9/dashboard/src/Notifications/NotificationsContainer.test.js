import React from 'react';
import { shallow } from 'enzyme';
import { fromJS } from 'immutable';
import { NotificationsContainer, mapStateToProps } from './NotificationsContainer';
import Notifications from './Notifications';

describe('<NotificationsContainer />', () => {
  it('fetches the notifications when it is mounted', () => {
    const fetchNotifications = jest.fn();
    shallow(<NotificationsContainer fetchNotifications={fetchNotifications} />);
    expect(fetchNotifications).toHaveBeenCalledTimes(1);
  });

  it('renders Notifications and passes the props through', () => {
    const handleHideDrawer = jest.fn();
    const wrapper = shallow(
      <NotificationsContainer displayDrawer={true} handleHideDrawer={handleHideDrawer} />
    );
    const notifications = wrapper.find(Notifications);
    expect(notifications).toHaveLength(1);
    expect(notifications.prop('displayDrawer')).toBe(true);
    expect(notifications.prop('handleHideDrawer')).toBe(handleHideDrawer);
    expect(notifications.prop('fetchNotifications')).toBeUndefined();
  });
});

describe('NotificationsContainer mapStateToProps', () => {
  it('maps listNotifications to the unread notifications', () => {
    const state = {
      notifications: fromJS({
        filter: 'DEFAULT',
        messages: {
          g1: { guid: 'g1', isRead: false, type: 'default', value: 'Unread' },
          g2: { guid: 'g2', isRead: true, type: 'urgent', value: 'Read' },
        },
      }),
    };
    const guids = mapStateToProps(state).listNotifications.map((n) => n.get('guid')).toArray();
    expect(guids).toEqual(['g1']);
  });
});
