import {
  markAsAread,
  setNotificationFilter,
  setLoadingState,
  setNotifications,
  fetchNotifications,
} from './notificationActionCreators';
import {
  MARK_AS_READ,
  SET_TYPE_FILTER,
  SET_LOADING_STATE,
  FETCH_NOTIFICATIONS_SUCCESS,
  NotificationTypeFilters,
} from './notificationActionTypes';

const data = [
  {
    id: '1',
    author: { id: 'u1', name: { first: 'Poole', last: 'Sanders' } },
    context: { guid: 'g1', isRead: false, type: 'urgent', value: 'First' },
  },
];

describe('notification action creators', () => {
  afterEach(() => {
    delete global.fetch;
  });

  it('markAsAread returns the right action', () => {
    expect(markAsAread(1)).toEqual({ type: MARK_AS_READ, index: 1 });
  });

  it('setNotificationFilter returns the right action', () => {
    expect(setNotificationFilter(NotificationTypeFilters.DEFAULT)).toEqual({
      type: SET_TYPE_FILTER,
      filter: 'DEFAULT',
    });
  });

  it('setLoadingState returns the right action', () => {
    expect(setLoadingState(true)).toEqual({ type: SET_LOADING_STATE, loading: true });
    expect(setLoadingState(false)).toEqual({ type: SET_LOADING_STATE, loading: false });
  });

  it('setNotifications returns the right action', () => {
    expect(setNotifications(data)).toEqual({ type: FETCH_NOTIFICATIONS_SUCCESS, data });
  });

  it('fetchNotifications sets loading, stores the data, then stops loading', async () => {
    global.fetch = jest.fn(() => Promise.resolve({ json: () => Promise.resolve(data) }));
    const dispatch = jest.fn();

    await fetchNotifications()(dispatch);

    expect(global.fetch).toHaveBeenCalledWith('/notifications.json');
    expect(dispatch).toHaveBeenNthCalledWith(1, setLoadingState(true));
    expect(dispatch).toHaveBeenNthCalledWith(2, setNotifications(data));
    expect(dispatch).toHaveBeenNthCalledWith(3, setLoadingState(false));
  });

  it('fetchNotifications stops loading even when the API fails', async () => {
    global.fetch = jest.fn(() => Promise.reject(new Error('fail')));
    const dispatch = jest.fn();

    await fetchNotifications()(dispatch);

    expect(dispatch).toHaveBeenNthCalledWith(1, setLoadingState(true));
    expect(dispatch).toHaveBeenLastCalledWith(setLoadingState(false));
    expect(dispatch).toHaveBeenCalledTimes(2);
  });
});
