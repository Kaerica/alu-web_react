import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, css } from 'aphrodite';

const styles = StyleSheet.create({
  row: {
    backgroundColor: '#f5f5f5ab',
  },
  headerRow: {
    backgroundColor: '#deb5b545',
  },
  rowChecked: {
    backgroundColor: '#e6e4e4',
  },
  th: {
    borderBottom: '1px solid #ddd',
    textAlign: 'left',
    padding: '4px 8px',
  },
  thFullWidth: {
    textAlign: 'center',
  },
  td: {
    borderBottom: '1px solid #ddd',
    padding: '4px 8px',
  },
});

class CourseListRow extends Component {
  constructor(props) {
    super(props);
    this.state = { isChecked: false };
  }

  handleCheck = () => {
    this.setState((prev) => ({ isChecked: !prev.isChecked }));
  };

  render() {
    const { isHeader, textFirstCell, textSecondCell } = this.props;
    const { isChecked } = this.state;
    let content;

    if (isHeader) {
      content = textSecondCell === null ? (
        <th colSpan="2" className={css(styles.th, styles.thFullWidth)}>{textFirstCell}</th>
      ) : (
        <React.Fragment>
          <th className={css(styles.th)}>{textFirstCell}</th>
          <th className={css(styles.th)}>{textSecondCell}</th>
        </React.Fragment>
      );
    } else {
      content = (
        <React.Fragment>
          <td className={css(styles.td)}>
            <input type="checkbox" checked={isChecked} onChange={this.handleCheck} />
            {textFirstCell}
          </td>
          <td className={css(styles.td)}>{textSecondCell}</td>
        </React.Fragment>
      );
    }

    return (
      <tr className={css(isHeader ? styles.headerRow : styles.row, isChecked && styles.rowChecked)}>
        {content}
      </tr>
    );
  }
}

CourseListRow.propTypes = {
  isHeader: PropTypes.bool,
  textFirstCell: PropTypes.string.isRequired,
  textSecondCell: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

CourseListRow.defaultProps = {
  isHeader: false,
  textSecondCell: null,
};

export default CourseListRow;
