import React from 'react';
import { shallow } from 'enzyme';
import CourseList from './CourseList';
import CourseListRow from './CourseListRow';

const listCourses = [
  { id: 1, name: 'ES6', credit: 60 },
  { id: 2, name: 'Webpack', credit: 20 },
  { id: 3, name: 'React', credit: 40 },
];

describe('<CourseList />', () => {
  it('renders without crashing', () => {
    expect(shallow(<CourseList />).exists()).toBe(true);
  });

  it('renders the header rows and the course rows', () => {
    const wrapper = shallow(<CourseList listCourses={listCourses} />);
    expect(wrapper.find('thead').find(CourseListRow)).toHaveLength(2);
    expect(wrapper.find('tbody').find(CourseListRow)).toHaveLength(3);
  });

  it('renders the empty message with no courses', () => {
    const wrapper = shallow(<CourseList listCourses={[]} />);
    expect(wrapper.find('tbody').find(CourseListRow).props().textFirstCell)
      .toBe('No course available yet');
  });
});
