import React from 'react';
import { shallow } from 'enzyme';
import CourseListRow from './CourseListRow';

describe('<CourseListRow />', () => {
  it('renders one th with colSpan 2 when textSecondCell is missing', () => {
    const wrapper = shallow(<CourseListRow isHeader={true} textFirstCell="test" />);
    expect(wrapper.find('th')).toHaveLength(1);
    expect(wrapper.find('th').prop('colSpan')).toBe('2');
  });

  it('renders two th when textSecondCell is present', () => {
    const wrapper = shallow(<CourseListRow isHeader={true} textFirstCell="a" textSecondCell="b" />);
    expect(wrapper.find('th')).toHaveLength(2);
  });

  it('renders two td in a regular row', () => {
    const wrapper = shallow(<CourseListRow textFirstCell="a" textSecondCell="b" />);
    expect(wrapper.find('tr').children('td')).toHaveLength(2);
  });

  it('toggles the checked style when the checkbox changes', () => {
    const wrapper = shallow(<CourseListRow textFirstCell="a" textSecondCell="b" />);
    wrapper.find('input').simulate('change');
    expect(wrapper.find('tr').prop('className')).toMatch(/rowChecked/);
  });
});
