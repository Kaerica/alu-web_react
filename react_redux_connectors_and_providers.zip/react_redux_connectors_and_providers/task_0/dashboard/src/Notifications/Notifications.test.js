import React from 'react';
import { shallow } from 'enzyme';
import Notifications from './Notifications';
import NotificationItem from './NotificationItem';
import { getLatestNotification } from '../utils/utils';

const listNotifications = [
  { id: 1, type: 'default', value: 'New course available' },
  { id: 2, type: 'urgent', value: 'New resume available' },
  { id: 3, type: 'urgent', html: { __html: getLatestNotification() } },
];

describe('<Notifications />', () => {
  it('renders the menu item but not the drawer by default', () => {
    const wrapper = shallow(<Notifications />);
    expect(wrapper.text()).toContain('Your notifications');
    expect(wrapper.find('ul')).toHaveLength(0);
  });

  it('renders the list when displayDrawer is true', () => {
    const wrapper = shallow(<Notifications displayDrawer listNotifications={listNotifications} />);
    expect(wrapper.find(NotificationItem)).toHaveLength(3);
    expect(wrapper.text()).toContain('Here is the list of notifications');
  });

  it('renders the empty message with an empty list', () => {
    const wrapper = shallow(<Notifications displayDrawer listNotifications={[]} />);
    expect(wrapper.text()).toContain('No new notification for now');
  });

  it('calls handleDisplayDrawer when the menu item is clicked', () => {
    const handleDisplayDrawer = jest.fn();
    const wrapper = shallow(<Notifications handleDisplayDrawer={handleDisplayDrawer} />);
    wrapper.find('div').first().simulate('click');
    expect(handleDisplayDrawer).toHaveBeenCalled();
  });

  it('calls handleHideDrawer when the close button is clicked', () => {
    const handleHideDrawer = jest.fn();
    const wrapper = shallow(
      <Notifications displayDrawer listNotifications={listNotifications} handleHideDrawer={handleHideDrawer} />
    );
    wrapper.find('button[aria-label="Close"]').simulate('click');
    expect(handleHideDrawer).toHaveBeenCalled();
  });

  it('passes markNotificationAsRead to each item', () => {
    const markNotificationAsRead = jest.fn();
    const wrapper = shallow(
      <Notifications
        displayDrawer
        listNotifications={listNotifications}
        markNotificationAsRead={markNotificationAsRead}
      />
    );
    expect(wrapper.find(NotificationItem).first().prop('markAsRead')).toBe(markNotificationAsRead);
  });

  it('only rerenders when the list length or displayDrawer changes', () => {
    const wrapper = shallow(<Notifications displayDrawer listNotifications={listNotifications} />);
    const instance = wrapper.instance();
    expect(instance.shouldComponentUpdate({ displayDrawer: true, listNotifications })).toBe(false);
    expect(instance.shouldComponentUpdate({ displayDrawer: false, listNotifications })).toBe(true);
  });
});
