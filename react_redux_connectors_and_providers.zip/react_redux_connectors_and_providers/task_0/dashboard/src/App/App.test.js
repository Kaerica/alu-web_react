import React from 'react';
import { shallow } from 'enzyme';
import { fromJS } from 'immutable';
import { App, mapStateToProps } from './App';
import Notifications from '../Notifications/Notifications';
import Header from '../Header/Header';
import Login from '../Login/Login';
import Footer from '../Footer/Footer';
import CourseList from '../CourseList/CourseList';
import { defaultUser } from './AppContext';

describe('<App />', () => {
  it('renders without crashing', () => {
    expect(shallow(<App />).exists()).toBe(true);
  });

  it('contains Notifications, Header, Login and Footer', () => {
    const wrapper = shallow(<App />);
    expect(wrapper.find(Notifications)).toHaveLength(1);
    expect(wrapper.find(Header)).toHaveLength(1);
    expect(wrapper.find(Login)).toHaveLength(1);
    expect(wrapper.find(Footer)).toHaveLength(1);
    expect(wrapper.find(CourseList)).toHaveLength(0);
  });

  it('renders CourseList instead of Login when isLoggedIn is true', () => {
    const wrapper = shallow(<App isLoggedIn={true} />);
    expect(wrapper.find(Login)).toHaveLength(0);
    expect(wrapper.find(CourseList)).toHaveLength(1);
  });

  it('has displayDrawer set to false by default', () => {
    expect(shallow(<App />).state('displayDrawer')).toBe(false);
  });

  it('handleDisplayDrawer and handleHideDrawer update displayDrawer', () => {
    const wrapper = shallow(<App />);
    wrapper.instance().handleDisplayDrawer();
    expect(wrapper.state('displayDrawer')).toBe(true);
    wrapper.instance().handleHideDrawer();
    expect(wrapper.state('displayDrawer')).toBe(false);
  });

  it('logIn and logOut update the user', () => {
    const wrapper = shallow(<App />);
    wrapper.instance().logIn('a@b.com', 'pass');
    expect(wrapper.state('user')).toEqual({ email: 'a@b.com', password: 'pass', isLoggedIn: true });
    wrapper.instance().logOut();
    expect(wrapper.state('user')).toEqual(defaultUser);
  });

  it('markNotificationAsRead removes the notification', () => {
    const wrapper = shallow(<App />);
    wrapper.instance().markNotificationAsRead(1);
    expect(wrapper.state('listNotifications').map((n) => n.id)).toEqual([2, 3]);
  });
});

describe('mapStateToProps', () => {
  it('returns the right object when passing the state', () => {
    const state = fromJS({
      isUserLoggedIn: true,
    });
    expect(mapStateToProps(state)).toEqual({ isLoggedIn: true });
  });
});
