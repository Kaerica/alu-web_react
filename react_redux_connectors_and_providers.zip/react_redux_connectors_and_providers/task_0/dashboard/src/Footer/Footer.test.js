import React from 'react';
import { shallow, mount } from 'enzyme';
import Footer from './Footer';
import AppContext, { defaultUser } from '../App/AppContext';

describe('<Footer />', () => {
  it('renders without crashing', () => {
    const wrapper = shallow(<Footer />);
    expect(wrapper.exists()).toBe(true);
  });

  it('renders the text Copyright', () => {
    const wrapper = mount(<Footer />);
    expect(wrapper.text()).toContain('Copyright');
  });

  it('does not display the contact link when logged out', () => {
    const wrapper = mount(
      <AppContext.Provider value={{ user: defaultUser, logOut: () => {} }}>
        <Footer />
      </AppContext.Provider>
    );
    expect(wrapper.find('a')).toHaveLength(0);
  });

  it('displays the contact link when logged in', () => {
    const user = { email: 'a@b.com', password: 'pass', isLoggedIn: true };
    const wrapper = mount(
      <AppContext.Provider value={{ user, logOut: () => {} }}>
        <Footer />
      </AppContext.Provider>
    );
    expect(wrapper.find('a').text()).toBe('Contact us');
  });
});
