import uiReducer, { initialState } from './uiReducer';
import { DISPLAY_NOTIFICATION_DRAWER } from '../actions/uiActionTypes';
import { SELECT_COURSE } from '../actions/courseActionTypes';
import {
  hideNotificationDrawer,
  loginSuccess,
  loginFailure,
  logout,
} from '../actions/uiActionCreators';

describe('uiReducer', () => {
  it('returns the initial state when no action is passed', () => {
    expect(uiReducer(undefined, {}).toJS()).toEqual(initialState.toJS());
  });

  it('returns the initial state when SELECT_COURSE is passed', () => {
    expect(uiReducer(undefined, { type: SELECT_COURSE }).toJS()).toEqual(initialState.toJS());
  });

  it('changes isNotificationDrawerVisible on DISPLAY_NOTIFICATION_DRAWER', () => {
    const state = uiReducer(undefined, { type: DISPLAY_NOTIFICATION_DRAWER });
    expect(state.get('isNotificationDrawerVisible')).toBe(true);
  });

  it('changes isNotificationDrawerVisible on HIDE_NOTIFICATION_DRAWER', () => {
    const shown = uiReducer(undefined, { type: DISPLAY_NOTIFICATION_DRAWER });
    expect(uiReducer(shown, hideNotificationDrawer()).get('isNotificationDrawerVisible')).toBe(false);
  });

  it('updates isUserLoggedIn on LOGIN_SUCCESS, LOGIN_FAILURE and LOGOUT', () => {
    const loggedIn = uiReducer(undefined, loginSuccess());
    expect(loggedIn.get('isUserLoggedIn')).toBe(true);
    expect(uiReducer(loggedIn, loginFailure()).get('isUserLoggedIn')).toBe(false);
    expect(uiReducer(loggedIn, logout()).get('isUserLoggedIn')).toBe(false);
  });
});
