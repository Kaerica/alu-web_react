import courseReducer from './courseReducer';
import { setCourses, selectCourse, unSelectCourse } from '../actions/courseActionCreators';

const courses = [
  { id: '1', name: 'ES6', credit: 60 },
  { id: '2', name: 'Webpack', credit: 20 },
  { id: '3', name: 'React', credit: 40 },
];

describe('courseReducer', () => {
  it('returns an empty Map by default', () => {
    expect(courseReducer(undefined, {}).toJS()).toEqual({});
  });

  it('stores the courses with isSelected false on FETCH_COURSE_SUCCESS', () => {
    const state = courseReducer(undefined, setCourses(courses));
    expect(state.toJS()).toEqual({
      1: { id: '1', name: 'ES6', credit: 60, isSelected: false },
      2: { id: '2', name: 'Webpack', credit: 20, isSelected: false },
      3: { id: '3', name: 'React', credit: 40, isSelected: false },
    });
  });

  it('selects and unselects a course', () => {
    const fetched = courseReducer(undefined, setCourses(courses));
    const selected = courseReducer(fetched, selectCourse('2'));
    expect(selected.getIn(['2', 'isSelected'])).toBe(true);
    const unselected = courseReducer(selected, unSelectCourse('2'));
    expect(unselected.getIn(['2', 'isSelected'])).toBe(false);
  });
});
