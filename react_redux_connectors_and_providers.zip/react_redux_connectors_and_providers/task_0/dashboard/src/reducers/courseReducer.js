import { Map, fromJS } from 'immutable';
import { SELECT_COURSE, UNSELECT_COURSE, FETCH_COURSE_SUCCESS } from '../actions/courseActionTypes';
import { coursesNormalizer } from '../schema/courses';

export const initialState = Map();

export default function courseReducer(state = initialState, action = {}) {
  switch (action.type) {
    case FETCH_COURSE_SUCCESS: {
      const data = action.data.map((course) => ({ ...course, isSelected: false }));
      const { courses } = coursesNormalizer(data).entities;
      return state.merge(fromJS(courses || {}));
    }
    case SELECT_COURSE:
      if (!state.has(String(action.index))) return state;
      return state.setIn([String(action.index), 'isSelected'], true);
    case UNSELECT_COURSE:
      if (!state.has(String(action.index))) return state;
      return state.setIn([String(action.index), 'isSelected'], false);
    default:
      return state;
  }
}
