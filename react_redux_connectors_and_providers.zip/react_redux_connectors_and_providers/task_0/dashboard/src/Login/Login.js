import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, css } from 'aphrodite';

const screenSmall = '@media (max-width: 900px)';

const styles = StyleSheet.create({
  inputGroup: {
    display: 'inline-block',
    [screenSmall]: {
      display: 'block',
      marginBottom: '8px',
    },
  },
  input: {
    margin: '0 16px 0 8px',
  },
  button: {
    [screenSmall]: {
      display: 'block',
    },
  },
});

class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: '',
      enableSubmit: false,
    };
  }

  handleLoginSubmit = (event) => {
    event.preventDefault();
    const { email, password } = this.state;
    this.props.logIn(email, password);
  };

  handleChangeEmail = (event) => {
    const email = event.target.value;
    this.setState((prev) => ({ email, enableSubmit: email !== '' && prev.password !== '' }));
  };

  handleChangePassword = (event) => {
    const password = event.target.value;
    this.setState((prev) => ({ password, enableSubmit: prev.email !== '' && password !== '' }));
  };

  render() {
    const { email, password, enableSubmit } = this.state;

    return (
      <div>
        <p>Login to access the full dashboard</p>
        <form onSubmit={this.handleLoginSubmit}>
          <div className={css(styles.inputGroup)}>
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              className={css(styles.input)}
              value={email}
              onChange={this.handleChangeEmail}
            />
          </div>
          <div className={css(styles.inputGroup)}>
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              className={css(styles.input)}
              value={password}
              onChange={this.handleChangePassword}
            />
          </div>
          <input
            type="submit"
            value="OK"
            className={css(styles.button)}
            disabled={!enableSubmit}
          />
        </form>
      </div>
    );
  }
}

Login.propTypes = {
  logIn: PropTypes.func,
};

Login.defaultProps = {
  logIn: () => {},
};

export default Login;
