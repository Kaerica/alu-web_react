import React from 'react';
import { shallow } from 'enzyme';
import Login from './Login';

describe('<Login />', () => {
  it('renders without crashing', () => {
    const wrapper = shallow(<Login />);
    expect(wrapper.exists()).toBe(true);
  });

  it('renders 2 text inputs and 2 labels', () => {
    const wrapper = shallow(<Login />);
    expect(wrapper.find('input#email')).toHaveLength(1);
    expect(wrapper.find('input#password')).toHaveLength(1);
    expect(wrapper.find('label')).toHaveLength(2);
  });

  it('disables the submit button by default', () => {
    const wrapper = shallow(<Login />);
    expect(wrapper.find('input[type="submit"]').prop('disabled')).toBe(true);
  });

  it('enables the submit button once both fields are filled', () => {
    const wrapper = shallow(<Login />);
    wrapper.find('input#email').simulate('change', { target: { value: 'a@b.com' } });
    wrapper.find('input#password').simulate('change', { target: { value: 'pass' } });
    expect(wrapper.find('input[type="submit"]').prop('disabled')).toBe(false);
  });

  it('calls logIn with the email and password on submit', () => {
    const logIn = jest.fn();
    const wrapper = shallow(<Login logIn={logIn} />);
    wrapper.find('input#email').simulate('change', { target: { value: 'a@b.com' } });
    wrapper.find('input#password').simulate('change', { target: { value: 'pass' } });
    wrapper.find('form').simulate('submit', { preventDefault: () => {} });
    expect(logIn).toHaveBeenCalledWith('a@b.com', 'pass');
  });
});
