import { fromJS } from 'immutable';
import {
  filterTypeSelected,
  getNotifications,
  getUnreadNotifications,
} from './notificationSelector';

const state = fromJS({
  filter: 'DEFAULT',
  messages: {
    g1: { guid: 'g1', isRead: false, type: 'urgent', value: 'First' },
    g2: { guid: 'g2', isRead: true, type: 'default', value: 'Second' },
    g3: { guid: 'g3', isRead: false, type: 'default', value: 'Third' },
  },
});

describe('notification selectors', () => {
  it('filterTypeSelected returns the filter', () => {
    expect(filterTypeSelected(state)).toBe('DEFAULT');
  });

  it('getNotifications returns the messages Map', () => {
    expect(getNotifications(state).size).toBe(3);
  });

  it('getUnreadNotifications returns only the unread messages', () => {
    const unread = getUnreadNotifications(state).map((m) => m.get('guid')).toArray();
    expect(unread).toEqual(['g1', 'g3']);
  });
});
