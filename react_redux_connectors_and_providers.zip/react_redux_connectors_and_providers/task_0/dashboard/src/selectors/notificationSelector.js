export const filterTypeSelected = (state) => state.get('filter');

export const getNotifications = (state) => state.get('messages');

export const getUnreadNotifications = (state) => state
  .get('messages')
  .valueSeq()
  .filter((message) => !message.get('isRead'));
