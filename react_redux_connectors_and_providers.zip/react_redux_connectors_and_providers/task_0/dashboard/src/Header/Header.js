import React, { Component } from 'react';
import { StyleSheet, css } from 'aphrodite';
import logo from '../assets/holberton-logo.jpg';
import AppContext from '../App/AppContext';

const styles = StyleSheet.create({
  header: {
    display: 'flex',
    alignItems: 'center',
    color: '#e0354b',
    borderBottom: '3px solid #e0354b',
  },
  logo: {
    width: '200px',
    height: '200px',
  },
  logoutSection: {
    padding: '0 24px',
  },
});

class Header extends Component {
  render() {
    const { user, logOut } = this.context;

    return (
      <React.Fragment>
        <div className={css(styles.header)}>
          <img src={logo} className={css(styles.logo)} alt="Holberton logo" />
          <h1>School dashboard</h1>
        </div>
        {user.isLoggedIn && (
          <section id="logoutSection" className={css(styles.logoutSection)}>
            Welcome <strong>{user.email}</strong>{' '}
            <em>
              <a href="#" onClick={logOut}>(logout)</a>
            </em>
          </section>
        )}
      </React.Fragment>
    );
  }
}

Header.contextType = AppContext;

export default Header;
