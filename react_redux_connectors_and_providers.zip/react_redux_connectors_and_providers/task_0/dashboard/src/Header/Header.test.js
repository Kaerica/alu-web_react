import React from 'react';
import { shallow, mount } from 'enzyme';
import Header from './Header';
import AppContext, { defaultUser } from '../App/AppContext';

describe('<Header />', () => {
  it('renders without crashing', () => {
    const wrapper = shallow(<Header />);
    expect(wrapper.exists()).toBe(true);
  });

  it('renders an img and a h1', () => {
    const wrapper = shallow(<Header />);
    expect(wrapper.find('img')).toHaveLength(1);
    expect(wrapper.find('h1').text()).toBe('School dashboard');
  });

  it('does not render the logout section with the default context', () => {
    const wrapper = mount(
      <AppContext.Provider value={{ user: defaultUser, logOut: () => {} }}>
        <Header />
      </AppContext.Provider>
    );
    expect(wrapper.find('#logoutSection')).toHaveLength(0);
  });

  it('renders the logout section when the user is logged in', () => {
    const user = { email: 'a@b.com', password: 'pass', isLoggedIn: true };
    const wrapper = mount(
      <AppContext.Provider value={{ user, logOut: () => {} }}>
        <Header />
      </AppContext.Provider>
    );
    expect(wrapper.find('#logoutSection')).toHaveLength(1);
  });

  it('calls logOut when the logout link is clicked', () => {
    const logOut = jest.fn();
    const user = { email: 'a@b.com', password: 'pass', isLoggedIn: true };
    const wrapper = mount(
      <AppContext.Provider value={{ user, logOut }}>
        <Header />
      </AppContext.Provider>
    );
    wrapper.find('#logoutSection a').simulate('click');
    expect(logOut).toHaveBeenCalled();
  });
});
