import {
  login,
  logout,
  displayNotificationDrawer,
  hideNotificationDrawer,
  loginSuccess,
  loginFailure,
  loginRequest,
} from './uiActionCreators';
import {
  LOGIN,
  LOGOUT,
  DISPLAY_NOTIFICATION_DRAWER,
  HIDE_NOTIFICATION_DRAWER,
  LOGIN_SUCCESS,
  LOGIN_FAILURE,
} from './uiActionTypes';

describe('ui action creators', () => {
  afterEach(() => {
    delete global.fetch;
  });

  it('login returns the right action', () => {
    expect(login('test@test.com', 'pass')).toEqual({
      type: LOGIN,
      user: { email: 'test@test.com', password: 'pass' },
    });
  });

  it('logout returns the right action', () => {
    expect(logout()).toEqual({ type: LOGOUT });
  });

  it('displayNotificationDrawer returns the right action', () => {
    expect(displayNotificationDrawer()).toEqual({ type: DISPLAY_NOTIFICATION_DRAWER });
  });

  it('hideNotificationDrawer returns the right action', () => {
    expect(hideNotificationDrawer()).toEqual({ type: HIDE_NOTIFICATION_DRAWER });
  });

  it('loginSuccess and loginFailure return the right actions', () => {
    expect(loginSuccess()).toEqual({ type: LOGIN_SUCCESS });
    expect(loginFailure()).toEqual({ type: LOGIN_FAILURE });
  });

  it('loginRequest dispatches LOGIN then LOGIN_SUCCESS when the API answers', async () => {
    global.fetch = jest.fn(() => Promise.resolve({ json: () => Promise.resolve({}) }));
    const dispatch = jest.fn();

    await loginRequest('test@test.com', 'pass')(dispatch);

    expect(global.fetch).toHaveBeenCalledWith('/login-success.json');
    expect(dispatch).toHaveBeenNthCalledWith(1, login('test@test.com', 'pass'));
    expect(dispatch).toHaveBeenNthCalledWith(2, loginSuccess());
  });

  it('loginRequest dispatches LOGIN then LOGIN_FAILURE when the API fails', async () => {
    global.fetch = jest.fn(() => Promise.reject(new Error('fail')));
    const dispatch = jest.fn();

    await loginRequest('test@test.com', 'pass')(dispatch);

    expect(dispatch).toHaveBeenNthCalledWith(1, login('test@test.com', 'pass'));
    expect(dispatch).toHaveBeenNthCalledWith(2, loginFailure());
  });
});
