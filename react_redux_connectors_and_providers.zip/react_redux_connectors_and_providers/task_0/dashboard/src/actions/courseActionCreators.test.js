import { selectCourse, unSelectCourse, setCourses } from './courseActionCreators';
import { SELECT_COURSE, UNSELECT_COURSE, FETCH_COURSE_SUCCESS } from './courseActionTypes';

describe('course action creators', () => {
  it('selectCourse returns the right action', () => {
    expect(selectCourse(1)).toEqual({ type: SELECT_COURSE, index: 1 });
  });

  it('unSelectCourse returns the right action', () => {
    expect(unSelectCourse(1)).toEqual({ type: UNSELECT_COURSE, index: 1 });
  });

  it('setCourses returns the right action', () => {
    const data = [{ id: '1', name: 'ES6', credit: 60 }];
    expect(setCourses(data)).toEqual({ type: FETCH_COURSE_SUCCESS, data });
  });
});
