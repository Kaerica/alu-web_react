import Enzyme from 'enzyme';
import Adapter from '@wojtekmaj/enzyme-adapter-react-17';
import { StyleSheetTestUtils } from 'aphrodite';

Enzyme.configure({ adapter: new Adapter() });

// Aphrodite tries to inject styles into the DOM; disable it for every test.
StyleSheetTestUtils.suppressStyleInjection();
