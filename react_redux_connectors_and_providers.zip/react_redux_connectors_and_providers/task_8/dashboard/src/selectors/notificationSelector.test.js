import { fromJS } from 'immutable';
import {
  filterTypeSelected,
  getNotifications,
  getUnreadNotificationsByType,
} from './notificationSelector';

const messages = {
  g1: { guid: 'g1', isRead: false, type: 'urgent', value: 'First' },
  g2: { guid: 'g2', isRead: true, type: 'urgent', value: 'Second' },
  g3: { guid: 'g3', isRead: false, type: 'default', value: 'Third' },
};

const guids = (seq) => seq.map((m) => m.get('guid')).toArray();

describe('notification selectors', () => {
  it('filterTypeSelected returns the filter', () => {
    expect(filterTypeSelected(fromJS({ filter: 'DEFAULT', messages }))).toBe('DEFAULT');
  });

  it('getNotifications returns the messages Map', () => {
    expect(getNotifications(fromJS({ filter: 'DEFAULT', messages })).size).toBe(3);
  });

  it('returns every unread notification when the filter is DEFAULT', () => {
    const state = fromJS({ filter: 'DEFAULT', messages });
    expect(guids(getUnreadNotificationsByType(state))).toEqual(['g1', 'g3']);
  });

  it('returns only the unread urgent notifications when the filter is URGENT', () => {
    const state = fromJS({ filter: 'URGENT', messages });
    expect(guids(getUnreadNotificationsByType(state))).toEqual(['g1']);
  });
});
