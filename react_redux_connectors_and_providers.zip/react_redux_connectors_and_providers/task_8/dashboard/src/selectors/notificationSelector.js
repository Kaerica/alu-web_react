import { createSelector } from 'reselect';
import { NotificationTypeFilters } from '../actions/notificationActionTypes';

export const filterTypeSelected = (state) => state.get('filter');

export const getNotifications = (state) => state.get('messages');

export const getUnreadNotificationsByType = createSelector(
  [filterTypeSelected, getNotifications],
  (filter, messages) => {
    const unread = messages.valueSeq().filter((message) => !message.get('isRead'));

    if (filter === NotificationTypeFilters.URGENT) {
      return unread.filter((message) => message.get('type') === 'urgent');
    }
    return unread;
  },
);
