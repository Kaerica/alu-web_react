import React from 'react';
import { shallow } from 'enzyme';
import { fromJS, Map } from 'immutable';
import { Notifications, mapStateToProps } from './Notifications';
import NotificationItem from './NotificationItem';

const listNotifications = fromJS({
  g1: { guid: 'g1', isRead: false, type: 'default', value: 'New course available' },
  g2: { guid: 'g2', isRead: false, type: 'urgent', value: 'New resume available' },
  g3: { guid: 'g3', isRead: false, type: 'urgent', value: 'Urgent requirement' },
});

describe('<Notifications />', () => {
  it('calls fetchNotifications when the component is mounted', () => {
    const fetchNotifications = jest.fn();
    shallow(<Notifications fetchNotifications={fetchNotifications} />);
    expect(fetchNotifications).toHaveBeenCalledTimes(1);
  });

  it('renders the menu item but not the drawer by default', () => {
    const wrapper = shallow(<Notifications />);
    expect(wrapper.text()).toContain('Your notifications');
    expect(wrapper.find('ul')).toHaveLength(0);
  });

  it('renders one NotificationItem per notification when displayDrawer is true', () => {
    const wrapper = shallow(<Notifications displayDrawer listNotifications={listNotifications} />);
    expect(wrapper.find(NotificationItem)).toHaveLength(3);
    expect(wrapper.text()).toContain('Here is the list of notifications');
    const first = wrapper.find(NotificationItem).first();
    expect(first.prop('id')).toBe('g1');
    expect(first.prop('type')).toBe('default');
    expect(first.prop('value')).toBe('New course available');
  });

  it('renders the empty message with no notifications', () => {
    const wrapper = shallow(<Notifications displayDrawer listNotifications={Map()} />);
    expect(wrapper.text()).toContain('No new notification for now');
  });

  it('calls handleDisplayDrawer when the menu item is clicked', () => {
    const handleDisplayDrawer = jest.fn();
    const wrapper = shallow(<Notifications handleDisplayDrawer={handleDisplayDrawer} />);
    wrapper.find('div').first().simulate('click');
    expect(handleDisplayDrawer).toHaveBeenCalled();
  });

  it('calls handleHideDrawer when the close button is clicked', () => {
    const handleHideDrawer = jest.fn();
    const wrapper = shallow(
      <Notifications displayDrawer listNotifications={listNotifications} handleHideDrawer={handleHideDrawer} />
    );
    wrapper.find('button[aria-label="Close"]').simulate('click');
    expect(handleHideDrawer).toHaveBeenCalled();
  });

  it('passes markNotificationAsRead to each NotificationItem', () => {
    const markNotificationAsRead = jest.fn();
    const wrapper = shallow(
      <Notifications
        displayDrawer
        listNotifications={listNotifications}
        markNotificationAsRead={markNotificationAsRead}
      />
    );
    wrapper.find(NotificationItem).forEach((item) => {
      expect(item.prop('markAsRead')).toBe(markNotificationAsRead);
    });
  });

  it('calls setNotificationFilter with URGENT when the first button is clicked', () => {
    const setNotificationFilter = jest.fn();
    const wrapper = shallow(
      <Notifications
        displayDrawer
        listNotifications={listNotifications}
        setNotificationFilter={setNotificationFilter}
      />
    );
    const button = wrapper.find('button').filterWhere((b) => b.text().includes('‼️'));
    button.simulate('click');
    expect(setNotificationFilter).toHaveBeenCalledWith('URGENT');
  });

  it('calls setNotificationFilter with DEFAULT when the second button is clicked', () => {
    const setNotificationFilter = jest.fn();
    const wrapper = shallow(
      <Notifications
        displayDrawer
        listNotifications={listNotifications}
        setNotificationFilter={setNotificationFilter}
      />
    );
    const button = wrapper.find('button').filterWhere((b) => b.text().includes('💠'));
    button.simulate('click');
    expect(setNotificationFilter).toHaveBeenCalledWith('DEFAULT');
  });

  it('only rerenders when the list or displayDrawer changes', () => {
    const wrapper = shallow(<Notifications displayDrawer listNotifications={listNotifications} />);
    const instance = wrapper.instance();
    expect(instance.shouldComponentUpdate({ displayDrawer: true, listNotifications })).toBe(false);
    expect(instance.shouldComponentUpdate({ displayDrawer: false, listNotifications })).toBe(true);
  });
});

describe('Notifications mapStateToProps', () => {
  it('maps listNotifications to the unread messages using the selector', () => {
    const state = {
      notifications: fromJS({
        filter: 'DEFAULT',
        messages: {
          g1: { guid: 'g1', isRead: false, type: 'default', value: 'Unread' },
          g2: { guid: 'g2', isRead: true, type: 'urgent', value: 'Read' },
        },
      }),
    };
    const guids = mapStateToProps(state).listNotifications.map((n) => n.get('guid')).toArray();
    expect(guids).toEqual(['g1']);
  });
});
