import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Map } from 'immutable';
import { StyleSheet, css } from 'aphrodite';
import NotificationItem from './NotificationItem';
import closeIcon from '../assets/close-icon.png';
import {
  fetchNotifications,
  markAsAread,
  setNotificationFilter,
} from '../actions/notificationActionCreators';
import { NotificationTypeFilters } from '../actions/notificationActionTypes';
import { getUnreadNotificationsByType } from '../selectors/notificationSelector';

const screenSmall = '@media (max-width: 900px)';

const opacityKeyframes = {
  from: {
    opacity: 0.5,
  },
  to: {
    opacity: 1,
  },
};

const translateKeyframes = {
  '0%': {
    transform: 'translateY(0px)',
  },
  '33%': {
    transform: 'translateY(-5px)',
  },
  '66%': {
    transform: 'translateY(5px)',
  },
  '100%': {
    transform: 'translateY(0px)',
  },
};

const styles = StyleSheet.create({
  menuItem: {
    float: 'right',
    position: 'relative',
    zIndex: 100,
    textAlign: 'right',
    backgroundColor: '#fff8f8',
    padding: '0 8px',
    ':hover': {
      cursor: 'pointer',
      animationName: [opacityKeyframes, translateKeyframes],
      animationDuration: '1s, 0.5s',
      animationIterationCount: '3',
    },
  },
  menuItemHidden: {
    display: 'none',
  },
  notifications: {
    float: 'right',
    width: '40%',
    border: '2px dashed #e0354b',
    padding: '6px 12px',
    margin: '0 8px 8px 0',
    backgroundColor: 'white',
    position: 'relative',
    zIndex: 10,
    [screenSmall]: {
      float: 'none',
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100%',
      height: '100vh',
      overflowY: 'auto',
      boxSizing: 'border-box',
      margin: 0,
      padding: 0,
      border: 'none',
      fontSize: '20px',
    },
  },
  closeButton: {
    float: 'right',
    background: 'transparent',
    border: 'none',
    cursor: 'pointer',
  },
  closeIcon: {
    width: '10px',
    height: '10px',
  },
  filterButton: {
    margin: '0 4px 8px 0',
    cursor: 'pointer',
  },
  list: {
    [screenSmall]: {
      padding: 0,
    },
  },
});

export class Notifications extends Component {
  componentDidMount() {
    this.props.fetchNotifications();
  }

  shouldComponentUpdate(nextProps) {
    return (
      nextProps.listNotifications !== this.props.listNotifications
      || nextProps.displayDrawer !== this.props.displayDrawer
    );
  }

  render() {
    const {
      displayDrawer,
      listNotifications,
      handleDisplayDrawer,
      handleHideDrawer,
      markNotificationAsRead,
      setNotificationFilter,
    } = this.props;
    const notifications = listNotifications.valueSeq();

    return (
      <React.Fragment>
        <div
          className={css(styles.menuItem, displayDrawer && styles.menuItemHidden)}
          onClick={handleDisplayDrawer}
        >
          <p>Your notifications</p>
        </div>
        {displayDrawer && (
          <div className={css(styles.notifications)}>
            <button
              type="button"
              className={css(styles.closeButton)}
              aria-label="Close"
              onClick={handleHideDrawer}
            >
              <img src={closeIcon} alt="close icon" className={css(styles.closeIcon)} />
            </button>
            <p>Here is the list of notifications</p>
            <button
              type="button"
              className={css(styles.filterButton)}
              onClick={() => setNotificationFilter(NotificationTypeFilters.URGENT)}
            >
              ‼️
            </button>
            <button
              type="button"
              className={css(styles.filterButton)}
              onClick={() => setNotificationFilter(NotificationTypeFilters.DEFAULT)}
            >
              💠
            </button>
            {notifications.count() === 0 ? (
              <p>No new notification for now</p>
            ) : (
              <React.Fragment>
                <ul className={css(styles.list)}>
                  {notifications.map((notification) => (
                    <NotificationItem
                      key={notification.get('guid')}
                      id={notification.get('guid')}
                      type={notification.get('type')}
                      value={notification.get('value')}
                      markAsRead={markNotificationAsRead}
                    />
                  )).toArray()}
                </ul>
              </React.Fragment>
            )}
          </div>
        )}
      </React.Fragment>
    );
  }
}

Notifications.propTypes = {
  displayDrawer: PropTypes.bool,
  listNotifications: PropTypes.object,
  handleDisplayDrawer: PropTypes.func,
  handleHideDrawer: PropTypes.func,
  markNotificationAsRead: PropTypes.func,
  fetchNotifications: PropTypes.func,
  setNotificationFilter: PropTypes.func,
};

Notifications.defaultProps = {
  displayDrawer: false,
  listNotifications: Map(),
  handleDisplayDrawer: () => {},
  handleHideDrawer: () => {},
  markNotificationAsRead: () => {},
  fetchNotifications: () => {},
  setNotificationFilter: () => {},
};

export function mapStateToProps(state) {
  return {
    listNotifications: getUnreadNotificationsByType(state.notifications),
  };
}

const mapDispatchToProps = {
  fetchNotifications,
  markNotificationAsRead: markAsAread,
  setNotificationFilter,
};

export default connect(mapStateToProps, mapDispatchToProps)(Notifications);
