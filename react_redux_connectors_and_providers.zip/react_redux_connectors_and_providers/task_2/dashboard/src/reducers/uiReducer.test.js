import uiReducer, { initialState } from './uiReducer';
import { DISPLAY_NOTIFICATION_DRAWER } from '../actions/uiActionTypes';
import { SELECT_COURSE } from '../actions/courseActionTypes';
import {
  hideNotificationDrawer,
  loginSuccess,
  loginFailure,
  logout,
  login,
} from '../actions/uiActionCreators';

describe('uiReducer', () => {
  it('returns the initial state when no action is passed', () => {
    expect(uiReducer(undefined, {}).toJS()).toEqual(initialState.toJS());
  });

  it('returns the initial state when SELECT_COURSE is passed', () => {
    expect(uiReducer(undefined, { type: SELECT_COURSE }).toJS()).toEqual(initialState.toJS());
  });

  it('changes isNotificationDrawerVisible on DISPLAY_NOTIFICATION_DRAWER', () => {
    const state = uiReducer(undefined, { type: DISPLAY_NOTIFICATION_DRAWER });
    expect(state.get('isNotificationDrawerVisible')).toBe(true);
  });

  it('changes isNotificationDrawerVisible on HIDE_NOTIFICATION_DRAWER', () => {
    const shown = uiReducer(undefined, { type: DISPLAY_NOTIFICATION_DRAWER });
    expect(uiReducer(shown, hideNotificationDrawer()).get('isNotificationDrawerVisible')).toBe(false);
  });

  it('updates isUserLoggedIn on LOGIN_SUCCESS, LOGIN_FAILURE and LOGOUT', () => {
    const loggedIn = uiReducer(undefined, loginSuccess());
    expect(loggedIn.get('isUserLoggedIn')).toBe(true);
    expect(uiReducer(loggedIn, loginFailure()).get('isUserLoggedIn')).toBe(false);
    expect(uiReducer(loggedIn, logout()).get('isUserLoggedIn')).toBe(false);
  });

  it('sets the user on LOGIN', () => {
    const state = uiReducer(undefined, login('a@b.com', 'pass'));
    expect(state.get('user')).toEqual({ email: 'a@b.com', password: 'pass' });
  });

  it('sets the user to null on LOGOUT', () => {
    const loggedIn = uiReducer(uiReducer(undefined, login('a@b.com', 'pass')), loginSuccess());
    const state = uiReducer(loggedIn, logout());
    expect(state.get('user')).toBeNull();
    expect(state.get('isUserLoggedIn')).toBe(false);
  });
});
