import { List, Map } from 'immutable';
import { getListCourses } from './courseSelector';
import courseReducer from '../reducers/courseReducer';
import { setCourses } from '../actions/courseActionCreators';

const courses = [
  { id: '1', name: 'ES6', credit: 60 },
  { id: '2', name: 'Webpack', credit: 20 },
  { id: '3', name: 'React', credit: 40 },
];

describe('getListCourses', () => {
  it('returns an empty List when there are no courses', () => {
    const result = getListCourses({ courses: Map() });
    expect(List.isList(result)).toBe(true);
    expect(result.size).toBe(0);
  });

  it('returns every course entity as a List', () => {
    const state = { courses: courseReducer(undefined, setCourses(courses)) };
    const result = getListCourses(state);
    expect(List.isList(result)).toBe(true);
    expect(result.toJS()).toEqual([
      { id: '1', name: 'ES6', credit: 60, isSelected: false },
      { id: '2', name: 'Webpack', credit: 20, isSelected: false },
      { id: '3', name: 'React', credit: 40, isSelected: false },
    ]);
  });
});
