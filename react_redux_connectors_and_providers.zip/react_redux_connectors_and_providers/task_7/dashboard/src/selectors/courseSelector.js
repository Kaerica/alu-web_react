// Returns every course entity stored in the course reducer as an Immutable List.
export const getCourses = (state) => state.courses;

export const getListCourses = (state) => getCourses(state).valueSeq().toList();
