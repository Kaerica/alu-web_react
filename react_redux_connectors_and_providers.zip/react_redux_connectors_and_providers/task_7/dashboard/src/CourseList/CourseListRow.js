import React from 'react';
import PropTypes from 'prop-types';
import { StyleSheet, css } from 'aphrodite';

const styles = StyleSheet.create({
  row: {
    backgroundColor: '#f5f5f5ab',
  },
  headerRow: {
    backgroundColor: '#deb5b545',
  },
  rowChecked: {
    backgroundColor: '#e6e4e4',
  },
  th: {
    borderBottom: '1px solid #ddd',
    textAlign: 'left',
    padding: '4px 8px',
  },
  thFullWidth: {
    textAlign: 'center',
  },
  td: {
    borderBottom: '1px solid #ddd',
    padding: '4px 8px',
  },
});

function CourseListRow({
  id,
  isHeader,
  textFirstCell,
  textSecondCell,
  isChecked,
  onChangeRow,
}) {
  let content;

  if (isHeader) {
    content = textSecondCell === null ? (
      <th colSpan="2" className={css(styles.th, styles.thFullWidth)}>{textFirstCell}</th>
    ) : (
      <React.Fragment>
        <th className={css(styles.th)}>{textFirstCell}</th>
        <th className={css(styles.th)}>{textSecondCell}</th>
      </React.Fragment>
    );
  } else {
    content = (
      <React.Fragment>
        <td className={css(styles.td)}>
          <input
            type="checkbox"
            checked={isChecked}
            onChange={(event) => onChangeRow(id, event.target.checked)}
          />
          {textFirstCell}
        </td>
        <td className={css(styles.td)}>{textSecondCell}</td>
      </React.Fragment>
    );
  }

  return (
    <tr className={css(isHeader ? styles.headerRow : styles.row, isChecked && styles.rowChecked)}>
      {content}
    </tr>
  );
}

CourseListRow.propTypes = {
  id: PropTypes.string,
  isHeader: PropTypes.bool,
  textFirstCell: PropTypes.string.isRequired,
  textSecondCell: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  isChecked: PropTypes.bool,
  onChangeRow: PropTypes.func,
};

CourseListRow.defaultProps = {
  id: '',
  isHeader: false,
  textSecondCell: null,
  isChecked: false,
  onChangeRow: () => {},
};

export default CourseListRow;
