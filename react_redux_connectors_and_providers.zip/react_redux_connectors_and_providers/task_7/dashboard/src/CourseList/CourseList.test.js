import React from 'react';
import { shallow } from 'enzyme';
import { fromJS, List } from 'immutable';
import { CourseList, mapStateToProps } from './CourseList';
import CourseListRow from './CourseListRow';

const listCourses = fromJS([
  { id: '1', name: 'ES6', credit: 60, isSelected: false },
  { id: '2', name: 'Webpack', credit: 20, isSelected: true },
  { id: '3', name: 'React', credit: 40, isSelected: false },
]);

describe('<CourseList />', () => {
  it('renders without crashing', () => {
    expect(shallow(<CourseList />).exists()).toBe(true);
  });

  it('dispatches fetchCourses when the component is mounted', () => {
    const fetchCourses = jest.fn();
    shallow(<CourseList fetchCourses={fetchCourses} />);
    expect(fetchCourses).toHaveBeenCalledTimes(1);
  });

  it('renders the header rows and one row per course', () => {
    const wrapper = shallow(<CourseList listCourses={listCourses} />);
    expect(wrapper.find('thead').find(CourseListRow)).toHaveLength(2);
    const rows = wrapper.find('tbody').find(CourseListRow);
    expect(rows).toHaveLength(3);
    expect(rows.at(1).prop('isChecked')).toBe(true);
    expect(rows.at(1).prop('textFirstCell')).toBe('Webpack');
  });

  it('renders the empty message with no courses', () => {
    const wrapper = shallow(<CourseList listCourses={List()} />);
    expect(wrapper.find('tbody').find(CourseListRow).prop('textFirstCell'))
      .toBe('No course available yet');
  });

  it('onChangeRow dispatches selectCourse and unSelectCourse', () => {
    const selectCourse = jest.fn();
    const unSelectCourse = jest.fn();
    const wrapper = shallow(
      <CourseList selectCourse={selectCourse} unSelectCourse={unSelectCourse} />
    );

    wrapper.instance().onChangeRow('1', true);
    expect(selectCourse).toHaveBeenCalledWith('1');
    expect(unSelectCourse).not.toHaveBeenCalled();

    wrapper.instance().onChangeRow('1', false);
    expect(unSelectCourse).toHaveBeenCalledWith('1');
  });
});

describe('CourseList mapStateToProps', () => {
  it('maps listCourses using getListCourses', () => {
    const state = { courses: fromJS({ 1: { id: '1', name: 'ES6', credit: 60, isSelected: false } }) };
    expect(mapStateToProps(state).listCourses.toJS()).toEqual([
      { id: '1', name: 'ES6', credit: 60, isSelected: false },
    ]);
  });
});
