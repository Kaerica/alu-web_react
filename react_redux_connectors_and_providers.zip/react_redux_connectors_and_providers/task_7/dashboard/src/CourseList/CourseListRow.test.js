import React from 'react';
import { shallow } from 'enzyme';
import CourseListRow from './CourseListRow';

describe('<CourseListRow />', () => {
  it('renders one th with colSpan 2 when textSecondCell is missing', () => {
    const wrapper = shallow(<CourseListRow isHeader={true} textFirstCell="test" />);
    expect(wrapper.find('th')).toHaveLength(1);
    expect(wrapper.find('th').prop('colSpan')).toBe('2');
  });

  it('renders two th when textSecondCell is present', () => {
    const wrapper = shallow(<CourseListRow isHeader={true} textFirstCell="a" textSecondCell="b" />);
    expect(wrapper.find('th')).toHaveLength(2);
  });

  it('renders two td in a regular row', () => {
    const wrapper = shallow(<CourseListRow textFirstCell="a" textSecondCell="b" />);
    expect(wrapper.find('tr').children('td')).toHaveLength(2);
  });

  it('uses the isChecked prop for the checkbox and the row style', () => {
    const wrapper = shallow(<CourseListRow id="1" textFirstCell="a" textSecondCell="b" isChecked={true} />);
    expect(wrapper.find('input').prop('checked')).toBe(true);
    expect(wrapper.find('tr').prop('className')).toMatch(/rowChecked/);
  });

  it('calls onChangeRow with the id and the checked value', () => {
    const onChangeRow = jest.fn();
    const wrapper = shallow(
      <CourseListRow id="2" textFirstCell="a" textSecondCell="b" onChangeRow={onChangeRow} />
    );
    wrapper.find('input').simulate('change', { target: { checked: true } });
    expect(onChangeRow).toHaveBeenCalledWith('2', true);
  });
});
