import {
  selectCourse,
  unSelectCourse,
  setCourses,
  fetchCourses,
} from './courseActionCreators';
import { SELECT_COURSE, UNSELECT_COURSE, FETCH_COURSE_SUCCESS } from './courseActionTypes';

const data = [
  { id: '1', name: 'ES6', credit: 60 },
  { id: '2', name: 'Webpack', credit: 20 },
  { id: '3', name: 'React', credit: 40 },
];

describe('course action creators', () => {
  afterEach(() => {
    delete global.fetch;
  });

  it('selectCourse returns the right action', () => {
    expect(selectCourse(1)).toEqual({ type: SELECT_COURSE, index: 1 });
  });

  it('unSelectCourse returns the right action', () => {
    expect(unSelectCourse(1)).toEqual({ type: UNSELECT_COURSE, index: 1 });
  });

  it('setCourses returns the right action', () => {
    expect(setCourses(data)).toEqual({ type: FETCH_COURSE_SUCCESS, data });
  });

  it('fetchCourses queries courses.json and dispatches setCourses with the data', async () => {
    global.fetch = jest.fn(() => Promise.resolve({ json: () => Promise.resolve(data) }));
    const dispatch = jest.fn();

    await fetchCourses()(dispatch);

    expect(global.fetch).toHaveBeenCalledWith('/courses.json');
    expect(dispatch).toHaveBeenCalledTimes(1);
    expect(dispatch).toHaveBeenCalledWith(setCourses(data));
  });

  it('fetchCourses does not dispatch when the API fails', async () => {
    global.fetch = jest.fn(() => Promise.reject(new Error('fail')));
    const dispatch = jest.fn();

    await fetchCourses()(dispatch);

    expect(dispatch).not.toHaveBeenCalled();
  });
});
