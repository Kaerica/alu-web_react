# React Redux connectors and providers

Connecting the Holberton School dashboard to a Redux store with `react-redux`:
connectors, providers, thunk middleware, the Redux DevTools, combined reducers,
selectors (with Reselect) and the container/component pattern.

Each `task_N/dashboard` folder is a standalone project:

```bash
cd task_N/dashboard
npm install
npm test        # Jest + Enzyme
npm start       # webpack dev server (serves dist/, including the JSON APIs)
```

## Tasks

| Folder | Tasks | What changes |
| ------ | ----- | ------------ |
| `task_0` | 0 - 2 | `mapStateToProps` + `connect` in `App`, store created with `createStore(uiReducer)` and passed through a `Provider`, `mapStateToProps` test |
| `task_1` | 3 - 6 | `displayDrawer` comes from the store, `displayNotificationDrawer` / `hideNotificationDrawer` mapped with the object form of `mapDispatchToProps`, drawer state and handlers removed |
| `task_2` | 7 - 12 | `redux-thunk` middleware, `loginRequest` mapped to `login`, `Header` and `Footer` connected to `user` (no more Context), `LOGIN` / `LOGOUT` set the user, tests use the stateless components with `shallow` |
| `task_3` | 13 | Redux DevTools support (`__REDUX_DEVTOOLS_EXTENSION_COMPOSE__` + thunk) |
| `task_4` | 14 - 16 | `rootReducer` built with `combineReducers` (`courses`, `notifications`, `ui`), store created from it |
| `task_5` | 17 - 21 | `setLoadingState`, `setNotifications`, `fetchNotifications`; `loading` + `SET_LOADING_STATE` + `mergeDeep` in the reducer; `Notifications` connected and fetching on mount |
| `task_6` | 22 | `Notifications` uses the `getUnreadNotifications` selector and `markAsAread` |
| `task_7` | 23 - 25 | `getListCourses` selector, `fetchCourses`, `CourseList` connected (`fetchCourses`, `selectCourse`, `unSelectCourse`, `onChangeRow`), `CourseListRow` without local state |
| `task_8` | 26 - 28 | Memoized `getUnreadNotificationsByType` selector (Reselect) and the ‼️ / 💠 filter buttons |
| `task_9` | 29 | `NotificationsContainer` (connection + fetch on mount) and a functional `Notifications` component |

## Learning objectives

- Redux connectors, `mapStateToProps` and `mapDispatchToProps`
- Mapping (async) action creators to components with Redux Thunk
- Providers and setting up the app's store
- Improving connector performance with Reselect
- Debugging the state with the Redux DevTools
